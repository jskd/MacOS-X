//
// Jérôme SKODA <contact@jeromeskoda.fr>
// M2 IMPAIR
//
//  GameScene.swift
//  AsteroidBullshit
//
//  Created by Hubert Phrinfo on 15/02/2018.
//  Copyright © 2018 profesor. All rights reserved.
//

import SpriteKit
import GameplayKit
import Darwin

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    private var label : SKLabelNode?
    private var spinnyNode : SKShapeNode?
    
    private let cat_ship = UInt32(4)
    private let cat_bullet = UInt32(1)
    private let cat_asteroid = UInt32(2)
    private var a_perdu = false
    
    override func didMove(to view: SKView) {
        self.physicsWorld.contactDelegate = self
    }
    
    func addAsteroid(parentAsteroid : SKSpriteNode, velocity : CGVector, size: CGSize) {
        let asteroid0 = SKSpriteNode.init(texture: parentAsteroid.texture, size: size)
        asteroid0.name = "asteroid"
        asteroid0.position = parentAsteroid.position
        asteroid0.physicsBody = SKPhysicsBody(rectangleOf: asteroid0.size)
        asteroid0.physicsBody?.velocity = velocity
        asteroid0.physicsBody?.categoryBitMask = cat_asteroid
        asteroid0.physicsBody?.collisionBitMask = cat_bullet + cat_asteroid
        asteroid0.physicsBody?.fieldBitMask = 0
        asteroid0.physicsBody?.contactTestBitMask = cat_bullet
        self.addChild(asteroid0)
        
    }
    
    func slitAsteroid(asteroid : SKSpriteNode) {
        
        var s = asteroid.size
        s.width *= 0.5
        s.height *= 0.5
        
        if(s.width >= 50) {
            
            var teta = CDouble( Float(arc4random_uniform(360)) )
            var vx = 250 * cos(teta)
            var vy = 250 * sin(teta)
            print("teta: \(teta) vx \(vx) xy \(vy)")
            
            addAsteroid(parentAsteroid : asteroid, velocity : CGVector(dx: vx, dy: vy) , size : s )
            
            teta = CDouble( Float(arc4random_uniform(360)) )
            vx = 250 * cos(teta)
            vy = 250 * sin(teta)
            print("teta: \(teta) vx \(vx) xy \(vy)")
            
            addAsteroid(parentAsteroid : asteroid, velocity : CGVector(dx: vx, dy: vy), size: s  )
            
        }
        asteroid.removeFromParent()
    }
    
    func perdu() {
        let loose = SKLabelNode()
        loose.text = "Perdu! (r pour rejouer)";
        loose.fontSize = 100;
        loose.fontColor = NSColor.init(red: 255, green: 0, blue: 0, alpha: 100);
        loose.position = CGPoint.init(x: self.frame.size.width/2, y: self.frame.size.height/2)
        self.addChild(loose)
        print("perdu (r pour rejouer)")
        self.a_perdu = true
    }
    
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        if (contact.bodyA.node?.name == "asteroid" && contact.bodyB.node?.name == "bullet") {
            if let asteroid = contact.bodyA.node as? SKSpriteNode {
                if let bullet = contact.bodyB.node as? SKSpriteNode {
                    slitAsteroid(asteroid: asteroid)
                    bullet.removeFromParent()
                }
            }
        }
        if contact.bodyB.node?.name == "asteroid" && contact.bodyA.node?.name == "bullet" {
            
            if let asteroid = contact.bodyB.node as? SKSpriteNode {
                if let bullet = contact.bodyA.node as? SKSpriteNode {
                    slitAsteroid(asteroid: asteroid)
                    bullet.removeFromParent()
                }
            }
        }
        
        if contact.bodyB.node?.name == "ship" && contact.bodyA.node?.name == "asteroid" {
            perdu()
        }
        
        
        if contact.bodyB.node?.name == "asteroid" && contact.bodyA.node?.name == "ship" {
            perdu()
        }
    }
    
    override func keyDown(with event: NSEvent) {
        switch event.keyCode {
        // Envois de missile
        case 0x31:
            if(!self.a_perdu) {
                let bulletNode = SKSpriteNode.init(texture: SKTexture(imageNamed: "obama.png"), size: CGSize.init(width: 60, height: 60))
                bulletNode.position = self.childNode(withName: "ship")!.position
                bulletNode.name = "bullet"
                bulletNode.physicsBody = SKPhysicsBody(rectangleOf: bulletNode.size)
                bulletNode.physicsBody?.velocity = CGVector(dx: 1000.9, dy: 0)
                bulletNode.physicsBody?.collisionBitMask = self.cat_asteroid
                bulletNode.physicsBody?.contactTestBitMask = 2
                bulletNode.physicsBody?.categoryBitMask = self.cat_bullet
                self.addChild(bulletNode)
            }
        // up
        case 126:
            if(!self.a_perdu) {
                self.childNode(withName: "ship")?.physicsBody?.velocity = CGVector(dx: 0, dy: 500)
            }
        // right
        case 125:
            if(!self.a_perdu) {
                self.childNode(withName: "ship")?.physicsBody?.velocity = CGVector(dx: 0, dy: -500)
            }
        // down
        case 124:
            if(!self.a_perdu) {
                self.childNode(withName: "ship")?.physicsBody?.velocity = CGVector(dx: 500, dy: 0)
            }
        // left
        case 123:
            if(!self.a_perdu) {
                self.childNode(withName: "ship")?.physicsBody?.velocity = CGVector(dx: -500, dy: 0)
            }
        // r (restart)
        case 15:
            if(self.a_perdu) {
                if let scene = SKScene(fileNamed: "GameScene") {
                    scene.scaleMode = .aspectFill
                    self.scene?.view?.presentScene(scene)
                }
            }

        default:
            print("keyDown: \(event.characters!) keyCode: \(event.keyCode)")
        }
    }
    
    
    override func update(_ currentTime: TimeInterval) {
        
        // Reaparition hors limite
        
        for node in self.children {
            
            if let child = node as? SKSpriteNode {
                
                if(child.name != "bullet") {
                    if( child.position.x > self.frame.size.width) {
                        child.position.x = 0
                    }
                    if( child.position.x < 0) {
                        child.position.x = self.frame.size.width
                    }
                    if( child.position.y > self.frame.size.height) {
                        child.position.y = 0
                    }
                    if( child.position.y < 0) {
                        child.position.y = self.frame.size.height
                    }
                }
            }
        }
    }
}
