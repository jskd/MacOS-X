//
//  MasterViewController.swift
//  MasterDetailTest
//
//  Created by Hubert Phrinfo on 15/03/2018.
//  Copyright © 2018 profesor. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController {

    var detailViewController: DetailViewController? = nil
    
    // https://www.irif.fr/~yunes/OSX/data.xml
    var objects = [
        ( label: "la vie de toto", data: [
            (url: "http://www.irif.fr/~yunes/OSX/Montagne/Everest.jpg", name: "toto"),
            (url: "http://upload.wikimedia.org/wikipedia/commons/9/9d/Imae.JPG", name: "toto"),
            (url: "http://upload.wikimedia.org/wikipedia/commons/9/9d/Imae.JPG", name: "toto"),
            (url: "http://upload.wikimedia.org/wikipedia/commons/9/9d/Imae.JPG", name: "toto"),
        ]),
        ( label: "La vie de lala",
          data: [
            (url: "http://upload.wikimedia.org/wikipedia/commons/9/9d/Imae.JPG", name: "lala"),
            (url: "http://upload.wikimedia.org/wikipedia/commons/9/9d/Imae.JPG", name: "lala"),
        ])
    ]


    override func viewDidLoad() {
        super.viewDidLoad()

        if let split = self.splitViewController {
            let controllers = split.viewControllers
            self.detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        self.clearsSelectionOnViewWillAppear = self.splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let (url,name) = objects[indexPath.section].data[indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = (url,name)
                controller.navigationItem.leftBarButtonItem = self.splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return objects[section].label
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return objects.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return objects[section].data.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let (_,name) = objects[indexPath.section].data[indexPath.row]
        cell.textLabel!.text = name
        return cell
    }

}

