//
//  DetailViewController.swift
//  MasterDetailTest
//
//  Created by Hubert Phrinfo on 15/03/2018.
//  Copyright © 2018 profesor. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var detailDescriptionLabel: UILabel!

    @IBOutlet weak var titleLabel: UILabel!

    @IBOutlet weak var image: UIImageView!
    

    func configureView() {
        // Update the user interface for the detail item.
        if let detail = self.detailItem {
            if let label = self.detailDescriptionLabel {
                label.text = detail.name
            }
            if let label = self.titleLabel {
                label.text = detail.url
            }
            
            if let url = URL(string: detail.url) {
                do {
                    print("plop1")
                    let data = try Data(contentsOf: url)
                    
                    print("plop2")
                    self.image?.image = UIImage(data: data)
                } catch {
                    print("bad url")
                }
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    var detailItem: (name:String, url:String)? {
        didSet {
            self.configureView()
        }
    }


}

